﻿namespace Arrow.DeveloperTest.Common.Enum
{
    /// <summary>
    /// Payment scheme enum
    /// </summary>
    public enum PaymentScheme
    {
        FasterPayments,
        Bacs,
        Chaps
    }
}
