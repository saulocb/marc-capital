﻿namespace Arrow.DeveloperTest.Domain.Entities
{
    public class MakePaymentResult
    {
        public bool Success { get; set; }
    }
}
