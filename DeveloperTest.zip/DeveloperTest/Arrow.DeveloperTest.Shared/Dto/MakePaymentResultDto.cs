﻿namespace Arrow.DeveloperTest.Shared.Dto
{
    public class MakePaymentResultDto
    {
        public bool Success { get; set; }
    }
}
